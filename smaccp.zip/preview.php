<?php
include('include/connection.php');
include("include/language.php");

echo $_SESSION['invoicehtml'];