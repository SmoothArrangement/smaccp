<?php
echo (strlen($_POST['login_pw']) > 3) ? 'true' : 'false';
?>
