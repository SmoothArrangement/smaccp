// ! Your application

(function($, window, document, undefined){

	// Put all JS you need in addition to script.js here

})(jQuery, this, document);